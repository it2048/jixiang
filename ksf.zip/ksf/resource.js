var s_bg = "images/bg.jpg";
var mian = "images/mian.png";
var player = "images/player.png";
var line = "images/line.png";
var run0 = "images/run0.png";
var run1 = "images/run1.png";
var trun0 = "images/trun0.png";
var trun1 = "images/trun1.png";
var coin = "images/coin.png";
var feiting = "images/feiting.png";
var win = "images/win.png";
var win0 = "images/win0.png";
var win1 = "images/win1.png";
var yun1 = "images/yun1.png";
var yun2 = "images/yun2.png";
var yun3 = "images/yun3.png";
var feiting0 = "images/feiting0.png";
var feiting1 = "images/feiting1.png";
var feiting2 = "images/feiting2.png"; 
var fenshu = "images/fenshu.png"; 
var wait0 = "images/wait0.png";
var wait1 = "images/wait1.png";
var wait2 = "images/wait2.png";
var yh10 = "images/yh10.png";
var yh11 = "images/yh11.png";
var yh12 = "images/yh12.png";
var yh13 = "images/yh13.png";
var yh20 = "images/yh20.png";
var yh21 = "images/yh21.png";
var yh22 = "images/yh22.png";
var yh23 = "images/yh23.png";
var yh30 = "images/yh30.png";
var yh31 = "images/yh31.png";
var yh32 = "images/yh32.png";
var yh33 = "images/yh33.png";
var y_chi = "images/chi.mp3";
var y_defen = "images/defen.mp3";
var y_fall = "images/fall.mp3";
var y_go = "images/go.mp3";
var y_over = "images/over.mp3";
var y_win = "images/win.mp3";
var y_btn = "images/btn.mp3";
var g_resources = [
    //image
    s_bg,
    mian,
    player,
    line,
    run0,
    run1,
    trun0,
    trun1,
    coin,
    feiting,
    win,
    win0,
    win1,
    yun1,
    yun2,
    yun3,
    feiting0,
    feiting1,
    feiting2,
    fenshu,
    wait0,
    wait1,
    wait2,
    // y_chi,
    // y_defen,
    // y_fall,
    // y_go,
    // y_over,
    // y_win,
    // y_btn,
    yh10,
    yh11,
    yh12,
    yh13,
    yh20,
    yh21,
    yh22,
    yh23,
    yh30,
    yh31,
    yh32,
    yh33
    //plist

    //fnt

    //tmx

    //bgm

    //effect
];