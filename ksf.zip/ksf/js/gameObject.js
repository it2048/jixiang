function gameObject(){
	return gameObject.prototype.init();
}

gameObject.prototype = {
	init: function(){
		this.speed = 2;
		this.x = -100;
		this.y = -100;
		this.skin = "";
		//this.plist = [];
		this.wenli = "";
		this.name = "";
		
		//return this;		
		
	},
	touch: function(){
		var _this = this;
		cc.eventManager.addListener({
            event: cc.EventListener.TOUCH_ONE_BY_ONE,
            swallowTouches: !0,
            onTouchBegan: function(a, b) {
                var c = b.getCurrentTarget(),
                    d = c.getContentSize(),
                    d = cc.rect(-50, -50, d.width + 80, d.height + 80),
                    e = c.convertToNodeSpace(a.getLocation());
                return cc.rectContainsPoint(d, e) ? (
                	//game.score += 1,
                	c.stopAllActions(), d = cc.sequence(cc.callFunc(function() {
                		//_this.skin.setTexture("images/" + _this.name + "Dead.png");
                		window.game.score += _this.score;
                		window.game._score.setString(window.game.score);
                        _this.dead();
                    },
                    this),  cc.delayTime(0.2), cc.callFunc(function() {
                    c.x = -100;
                    c.y = -100
                }, this), cc.callFunc(function() {
                    //_this.setState(GameConstants.SPRITE_STATE_RELEASE)
                })), c.runAction(d),  !0) : !1
            }
        }, _this.skin)
	},
	getState: function() {
        return this._state
    },
    setState: function(a) {
        this._state = a
    },
	action: function(){
		//cc.spriteFrameCache.addSpriteFrames(this.plist, this.wenli);
		for (var a = [], b = 0; 2 > b; b++) {
            //var c = cc.spriteFrameCache.getSpriteFrame(this.name + b + ".png");
            var c = cc.SpriteFrame.create("images/" + this.name + b + ".png",cc.rect(0,0,50, 30));
            a.push(c)
        }
        a = new cc.Animation(a, 0.05);
        this._actionFly = cc.animate(a);
        this.skin.runAction(cc.repeatForever(this._actionFly))
		
	},
	dead: function(){
		//cc.spriteFrameCache.addSpriteFrames(this.deadplist, this.deadwenli);
		//var c = cc.SpriteFrame.create("images/" + this.name +"2.png",cc.rect(0,0,50, 30));
		this.skin.setTexture("images/" + this.name + "Dead.png");
		
		
		switch(this.name){
			case "cockroach":
			window.game.result["cockroach"] += 1;
			break;
			case "fly":
			window.game.result["fly"] += 1;
			break;
			case "mosquitoe":
			window.game.result["mosquitoe"] += 1;
			break;
			case "mouse":
			window.game.result["mouse"] += 1;
			break;
		}
	},
	remove: function(){
		this.skin = null;
	}
}

function cockroach(config){
	gameObject.call(this, config);
	this.skin = cc.Sprite.create(cockroach0);
	this.y = -100;
	this.x = Math.floor(size.width * Math.random());
	//this.plist = cockroachPlist;
	this.wenli = cockroachWenli;
	//this.deadplist = cockroachDeadPlist;
	this.deadwenli = cockroachDeadWenli;
	this.name = "cockroach";
	this.score = 3;
	this.delay = 100;
	this.speed = 3;
	this.touch();
	this.action();
	this.move();
}

cockroach.prototype = new gameObject();

cockroach.prototype.move = function(){
		var a = cc.p(Math.floor(size.width /3 * Math.random()) + 30, Math.floor(size.height * Math.random())),
            b = cc.p(Math.floor(size.width /3 * Math.random()) + 60, Math.floor(size.height * Math.random())),
            c = cc.p(Math.floor((size.width / 2) * Math.random()), size.height+30);
            a = cc.bezierTo(this.speed, [a, b, c]);
            var delayt1 = cc.DelayTime.create(1.5 / speed);
	          var attackMethod = cc.CallFunc.create(function(){       //随机采取攻击模式
	              this.remove();
	              return;
	          }, this);
	          //var move = cc.MoveTo.create(1 / speed, cc.p(size.width+100, size.height+100));
	          //var sc = cc.Sequence.create(a, delayt1, attackMethod);

	          this._actionMove = cc.sequence(cc.DelayTime.create(Math.floor(this.delay * Math.random())  / 6),a, attackMethod);
		      this.skin.runAction(this._actionMove);
	}

function fly(config){
	gameObject.call(this, config);
	this.skin = cc.Sprite.create(fly0);
	this.x = size.width + 100;
	this.y = Math.floor(836 * Math.random());
	//this.plist = flyPlist;
	this.wenli = flyWenli;
	//this.deadplist = flyDeadPlist;
	this.deadwenli = flyDeadWenli;
	this.name = "fly";
	this.score = 2;
	this.delay = 100;
	this.touch();
	this.action();
	this.move();
}

fly.prototype = new gameObject();

fly.prototype.move = function(){
		var a = cc.p(Math.floor(200 * Math.random()) + 50, Math.floor(size.height * Math.random())),
            b = cc.p(Math.floor(200 * Math.random()) + 200, Math.floor(size.height * Math.random())),
            c = cc.p(0 - 50, Math.floor(size.height * Math.random()));
            a = cc.bezierTo(this.speed, [a, b, c]);
            var delayt1 = cc.DelayTime.create(1.5 / speed);
	          var attackMethod = cc.CallFunc.create(function(){       //随机采取攻击模式
	              this.remove();
	              return;
	          }, this);
	          //var move = cc.MoveTo.create(1 / speed, cc.p(size.width+100, size.height+100));
	          //var sc = cc.Sequence.create(a, delayt1, attackMethod);

	          this._actionMove = cc.sequence(cc.DelayTime.create(Math.floor(this.delay * Math.random())  / 6),a, attackMethod);
		      this.skin.runAction(this._actionMove);
	}


function mosquitoe(config){
	gameObject.call(this, config);
	this.skin = cc.Sprite.create(mosquitoe0);
	this.x = -50;
	this.y = Math.floor(836 * Math.random());
	//this.plist = mosquitoePlist;
	this.wenli = mosquitoeWenli;
	//this.deadplist =mosquitoeDeadPlist;
	this.deadwenli = mosquitoeDeadWenli;
	this.name = "mosquitoe";
	this.score = 1;
	this.delay = 100;
	this.touch();
	this.action();
	this.move();
}

mosquitoe.prototype = new gameObject();

mosquitoe.prototype.move = function(){
		var a = cc.p(Math.floor(200 * Math.random()) + 50, Math.floor(size.height * Math.random())),
            b = cc.p(Math.floor(200 * Math.random()) + 200, Math.floor(size.height * Math.random())),
            c = cc.p(size.width + 50, Math.floor(size.height * Math.random()));
            a = cc.bezierTo(this.speed, [a, b, c]);
            var delayt1 = cc.DelayTime.create(1.5 / speed);
	          var attackMethod = cc.CallFunc.create(function(){       //随机采取攻击模式
	              this.remove();
	              return;
	          }, this);
	          //var move = cc.MoveTo.create(1 / speed, cc.p(size.width+100, size.height+100));
	          //var sc = cc.Sequence.create(a, delayt1, attackMethod);

	          this._actionMove = cc.sequence(cc.DelayTime.create(Math.floor(this.delay * Math.random())  / 6),a, attackMethod);
		      this.skin.runAction(this._actionMove);
	}



function mouse(config){
	gameObject.call(this, config);
	this.skin = cc.Sprite.create(mouse0);
	this.x = -50;
	this.y = Math.floor((size.height * 0.17) * Math.random());
	//this.plist = mousePlist;
	this.wenli = mouseWenli;
	//this.deadplist =mouseDeadPlist;
	this.deadwenli = mouseDeadWenli;
	this.name = "mouse";
	this.delay = 100;
	this.score = 4;
	this.speed = 4;
	this.touch();
	this.action();
	this.move();
}

mouse.prototype = new gameObject();

mouse.prototype.move = function(){
		var a = cc.p(size.width+50,this.y);
            a = cc.moveTo(this.speed, a);
            var delayt1 = cc.DelayTime.create(15 / speed);
	          var attackMethod = cc.CallFunc.create(function(){       //随机采取攻击模式
	              
	              this.remove();
	              return;
	          }, this);
	          //var move = cc.MoveTo.create(1 / speed, cc.p(size.width+100, size.height+100));
	          //var sc = cc.Sequence.create(a, delayt1, attackMethod);

	          this._actionMove = cc.Sequence.create(cc.DelayTime.create(Math.floor(this.delay * Math.random())  / 6),  a, attackMethod);
		      this.skin.runAction(this._actionMove);
	}